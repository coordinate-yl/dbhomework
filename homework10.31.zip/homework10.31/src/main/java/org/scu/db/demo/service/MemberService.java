package org.scu.db.demo.service;

public interface MemberService {
}
