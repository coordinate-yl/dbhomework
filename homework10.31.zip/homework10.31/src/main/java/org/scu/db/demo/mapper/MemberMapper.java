package org.scu.db.demo.mapper;

public interface MemberMapper {
}
