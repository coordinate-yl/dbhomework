package org.scu.db.demo.service.impl;

public class MemberServiceImpl {
}
